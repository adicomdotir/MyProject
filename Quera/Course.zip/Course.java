public class Course {
	private Student[] students = new Student[10];
	private String courseName;
	private int count = 0;

	public boolean register(Student s) {
		if(count >= 10)
			return false;
		else {
			count++;
			Student[] temp = new Student[count];
			temp[count - 1] = s;
			for(int i=0; i<count-1; i++) {
				temp[i] = students[i];
			}
			students = temp;
		}
		return true;
	}

	public int getNumOfStudents() {
		return count;
	}

	public Student[] getStudents() {
		return students;
	}

	public String getName() {
		return courseName;
	}

	public void setName(String name) {
		this.courseName = name;
	}


}

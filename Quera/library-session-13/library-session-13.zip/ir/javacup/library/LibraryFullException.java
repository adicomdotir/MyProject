package ir.javacup.library;

public class LibraryFullException extends Exception {
	public LibraryFullException(String message) {
		super(message);
	}
}
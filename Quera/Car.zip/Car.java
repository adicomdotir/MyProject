
public class Car {
	int weight;
	String color;
	String name;

	public Car() {
		this(500, "White", "Fride");
	}

	public Car(String name) {
		this(500, "White", name);
	}

	public Car(String color, String name) {
		this(500, color, name);
	}

	public Car(int weight, String color, String name) {
		this.weight = weight;
		this.color = color;
		this.name = name;
	}
}

public class Matrix {
	private int row;
	private int column;
	private int[][] elements;

	public Matrix(int row, int column) {
		this.row = row;
		this.column = column;
		this.elements = new int[row][column];
	}

	public Matrix(int length){
		this.row = length;
		this.column = length;
		this.elements = new int[length][length];
	}

	public Matrix(int[][] elements){
		this.elements = elements;
		this.row = elements.length;
		this.column = elements[0].length;
	}

	public int getRow() {
		return this.row;
	}

	public int getColumn() {
		return this.column;
	}

	public int[][] getElements() {
		return this.elements;
	}

	public boolean add(Matrix newMatrix) {
		if (this.row == newMatrix.getRow() && this.column == newMatrix.getColumn()) {
			for (int i=0; i<this.row; i++) {
				for (int j=0; j<this.column; j++) {
					this.elements[i][j] += newMatrix.elements[i][j];
				}
			}
			return true;
		}
		return false;
	}

	public void setElement(int i, int j, int value){
		this.elements[i][j] = value;
	}

	public boolean isSquareMatrix() {
		return this.row == this.column;
	}

	public void toLowerTriangular() {
		if(isSquareMatrix()) {
			for (int i=0; i<this.row; i++) {
				for (int j=0; j<this.column; j++) {
					if(j>i) this.elements[i][j] = 0;
				}
			}
		}
	}

	public void toUpperTriangular() {
		if(isSquareMatrix()) {
			for (int i=0; i<this.row; i++) {
				for (int j=0; j<this.column; j++) {
					if(j<i) this.elements[i][j] = 0;
				}
			}
		}
	}

}

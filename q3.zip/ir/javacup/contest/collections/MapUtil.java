package ir.javacup.contest.collections;

import java.util.List;
import java.util.Map;

public interface MapUtil {
 	Map<String, Integer> frequency(List<String> list);
}

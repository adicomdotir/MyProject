package ir.javacup.contest.collections;

import java.util.List;

public interface ListUtil {
 	List<String> uniques(List<String> list);
}
